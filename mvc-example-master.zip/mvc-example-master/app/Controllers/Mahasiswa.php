<?php namespace Controllers;

use Models\Model_mhs;

class Mahasiswa
{
    private $mhs;

    public function __construct()
    {
        $this->mhs = new Model_mhs();
    }

    /* =====================================================
       HALAMAN UTAMA
    ===================================================== */
    public function index()
    {
        require_once 'app/Views/index.php';
    }


    /* =====================================================
       READ (LIST + DETAIL)
    ===================================================== */
    public function show_data()
    {
        if (!isset($_GET['i'])) {
            // tampil semua data
            $rs = $this->mhs->lihatData();
            require_once('app/Views/mhsList.php');
        } else {
            // tampil detail berdasarkan ID
            $id = $_GET['i'];
            $rs = $this->mhs->lihatDataDetail($id);
            require_once('app/Views/mhsDetail.php');
        }
    }


    /* =====================================================
       CREATE
    ===================================================== */
    public function save()
    {
        $nim  = $_POST['nim'] ?? null;
        $nama = $_POST['nama'] ?? null;

        if ($nim && $nama) {
            $this->mhs->simpanData($nim, $nama);
        }

        header("Location: ?act=show-data");
        exit();
    }


    /* =====================================================
       EDIT (MENAMPILKAN FORM)
    ===================================================== */
    public function edit_data()
    {
        if (!isset($_GET["i"])) {
            header("Location: ?act=show-data");
            exit();
        }

        $id = $_GET["i"];
        $rs = $this->mhs->lihatDataDetail($id);

        require_once "app/Views/mhsUpdate.php";
    }


    /* =====================================================
       UPDATE
    ===================================================== */
    public function update_data()
    {
        $id   = $_POST["id"] ?? null;
        $nim  = $_POST["nim"] ?? null;
        $nama = $_POST["nama"] ?? null;

        if ($id && $nim && $nama) {
            $this->mhs->editData($id, $nim, $nama);
        }

        header("Location: ?act=show-data");
        exit();
    }


    /* =====================================================
       DELETE
    ===================================================== */
    public function delete_data()
    {
        if (isset($_GET["i"])) {
            $this->mhs->hapusData($_GET["i"]);
        }

        header("Location: ?act=show-data");
        exit();
    }
}
